﻿$ErrorActionPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = 'SS Kontrol'
Add-Type -AssemblyName System.IO.Compression.FileSystem

# ======================= COLORS =======================
$e  = [char]27
$OR = "$e[38;2;230;130;60m"
$GD = "$e[38;2;220;185;110m"
$PU = "$e[38;2;150;110;200m"
$RD = "$e[38;2;200;90;90m"
$DK = "$e[38;2;120;120;120m"
$GR = "$e[38;2;80;220;120m"
$RS = "$e[0m"
try {
    Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class VTMode { [DllImport("kernel32.dll")] public static extern IntPtr GetStdHandle(int h); [DllImport("kernel32.dll")] public static extern bool GetConsoleMode(IntPtr h, out uint m); [DllImport("kernel32.dll")] public static extern bool SetConsoleMode(IntPtr h, uint m); }'
    $hOut = [VTMode]::GetStdHandle(-11); $mode = [uint32]0
    if ([VTMode]::GetConsoleMode($hOut, [ref]$mode)) { [void][VTMode]::SetConsoleMode($hOut, $mode -bor 4) }
} catch {}
try {
    Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
public struct CONSOLE_FONT_INFOEX {
    public uint cbSize; public uint nFont; public short dwFontSizeX; public short dwFontSizeY;
    public int FontFamily; public int FontWeight;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string FaceName;
}
public static class ConFont {
    [DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr GetStdHandle(int h);
    [DllImport("kernel32.dll", SetLastError = true)] public static extern bool SetCurrentConsoleFontEx(IntPtr h, bool max, ref CONSOLE_FONT_INFOEX f);
}
'@
    $cf = New-Object CONSOLE_FONT_INFOEX
    $cf.cbSize = [Runtime.InteropServices.Marshal]::SizeOf([type]'CONSOLE_FONT_INFOEX')
    $cf.FaceName = 'Consolas'; $cf.dwFontSizeX = 0; $cf.dwFontSizeY = 18; $cf.FontFamily = 54; $cf.FontWeight = 400
    [void][ConFont]::SetCurrentConsoleFontEx([ConFont]::GetStdHandle(-11), $false, [ref]$cf)
} catch {}
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

# ======================= LANGUAGE =======================
Clear-Host
Write-Host "$PU============================================================$RS"
Write-Host "$GD  Choose your language$RS"
Write-Host "$PU============================================================$RS"
Write-Host "  $OR[1]$RS English"
Write-Host "  $OR[2]$RS Türkçe"
$lc = Read-Host 'Language [1/2]'
$lang = if ($lc -eq '2') { 'tr' } else { 'en' }

$TX = @{
  en = @{
    banner   = 'SS CHECK'
    admin1   = '[!] Not running as administrator. Prefetch, BAM, event logs and Recycle Bin'
    admin2   = '    checks will be limited. Use Run.bat or "Run as administrator".'
    menu1    = '1) Quick scan (Desktop, Downloads, Documents, .minecraft, Recent, Temp)'
    menu2    = '2) Full scan  (all drives, slower)'
    menu3    = '3) Services and firewall check'
    menu4    = '4) Last boot time'
    menu5    = '5) USB analysis (connection history)'
    usbhd    = @('Device Name','First Connected','Last Connected','Capacity','Serial Number','Product Name','Description','Manufacturer','VID','PID','Revision','File System')
    usbnone  = '[+] No USB storage history found.'
    svcadmin = 'Run as administrator to check services.'
    choose   = 'Your choice (e.g. 13)'
    hint     = 'Write several numbers together to combine them. 13 = quick scan + services check.'
    svcask   = 'Also check services and firewall? [y/n]'
    finished = 'Scan finished in {0} seconds. Files checked: {1}'
    clean    = '[+] Nothing suspicious found.'
    found    = '[!] {0} finding(s):'
    closehint= 'Scan complete. Close this window with the X button in the corner.'
  }
  tr = @{
    banner   = 'SS KONTROL'
    admin1   = '[!] Yönetici olarak çalışmıyor. Prefetch, BAM, olay günlükleri ve Geri Dönüşüm Kutusu'
    admin2   = '    kontrolleri sınırlı olacak. Run.bat kullanın veya "Yönetici olarak çalıştır" seçin.'
    menu1    = '1) Hızlı tarama (Masaüstü, İndirilenler, Belgeler, .minecraft, Son Kullanılanlar, Temp)'
    menu2    = '2) Tam tarama (tüm sürücüler, daha yavaş)'
    menu3    = '3) Servis ve güvenlik duvarı kontrolü'
    menu4    = '4) Son açılış zamanı'
    menu5    = '5) USB analizi (bağlantı geçmişi)'
    usbhd    = @('Aygıt Adı','İlk Bağlantı','Son Bağlantı','Kapasite','Seri Numarası','Ürün Adı','Açıklama','Üretici Adı','VID','PID','Ürün Revizyonu','Dosya Sistemi')
    usbnone  = '[+] USB depolama geçmişi bulunamadı.'
    svcadmin = 'Servisleri kontrol etmek için yönetici olarak çalıştırın.'
    choose   = 'Seçiminiz (örn. 13)'
    hint     = 'Birden fazla seçmek için numaraları yan yana yaz. 13 = hızlı tarama + servis kontrolü.'
    svcask   = 'Servisler ve güvenlik duvarı da kontrol edilsin mi? [e/h]'
    finished = 'Tarama {0} saniyede bitti. Kontrol edilen dosya: {1}'
    clean    = '[+] Şüpheli bir şey bulunamadı.'
    found    = '[!] {0} bulgu:'
    closehint= 'Tarama tamamlandı. Pencereyi kapatmak için sağ üstteki X butonunu kullanın.'
  }
}
function T([string]$k) { $TX[$lang][$k] }

$ST = @{
  'Processes'='İşlemler'; 'Java modules'='Java modülleri'; 'Prefetch'='Prefetch'
  'Registry traces'='Kayıt defteri izleri'; 'Recycle Bin'='Geri Dönüşüm Kutusu'
  'Event logs'='Olay günlükleri'; 'Mods and launcher'='Modlar ve başlatıcı'
  'File scan'='Dosya taraması'; 'Listing files...'='Dosyalar listeleniyor...'; 'Done'='Bitti'
}
$CT = @{
  'Process'='İşlem'; 'Java Agent'='Java Ajanı'; 'Java Module'='Java Modülü'; 'Bypass'='Atlatma'
  'Deleted file'='Silinmiş dosya'; 'File'='Dosya'; 'Disguised'='Gizlenmiş dosya'
  'File content'='Dosya içeriği'; 'Folder'='Klasör'; 'Program'='Yaygın programlar'; 'Discord download'='Discord indirmeleri'; 'Mod'='Mod'; 'Version'='Sürüm'; 'Launcher'='Başlatıcı'
}

# ======================= CONFIG =======================
# Substring match on file / process names (lowercase)
$NameKeywords = @(
    'lilith','anubis','hack','hile','cheat','injector','trigger','wurst','aristois',
    'meteor','com-combat','comcombat','mathax','vape','liquidbounce','trainer',
    'bleachhack','aura','impactclient','sigma','dooms','raven','novoline','astolfo',
    'autoclicker','slinky','whiteout','killaura','aimassist','triggerbot','rusherhack',
    'salhack','konas','phobos','futureclient','gamesense','osiris','tenacity','huzuni',
    'weepcraft','ghostclient','prestige','kronos','wexside','zeroday','expensive',
    'augustus','raidercheat','hexclient','dreamclient'
)
# Short words: only match as a WHOLE WORD in the name (avoids "ares" in "hardware")
$StrictKeywords = @('ares','jex','exec','rise','future','impact','inertia','remix','exhibition','drip','azura','wolfram')
# Signatures searched inside jar entry names and exe/dll contents
$ContentSigs = @('lilith','anubis','killaura','autoclicker','vape','liquidbounce','wurst',
                 'aristois','bleachhack','mathax','impactclient','doomsday','meteorclient',
                 'triggerbot','aimassist')
$MaxContentSize = 10MB
$ContentExt  = @('.exe','.dll','.jar')
# Extensions where we check the real file header (catches renamed jar/exe)
$DisguiseExt = @('.txt','.dat','.tmp','.bin','.png','.jpg','.log','.cfg','.json','.pdf','.mp3')
$ScanExt = @('.exe','.dll','.jar','.zip','.rar','.7z','.lnk','.bat','.cmd','.ps1','.vbs','.scr') + $DisguiseExt
# ======================================================

# Commonly used programs: shown in their own section at the end (informational only)
$CommonApps = @('discord.exe','chrome.exe','msedge.exe','firefox.exe','opera.exe','brave.exe',
    'steam.exe','epicgameslauncher.exe','spotify.exe','obs64.exe','obs32.exe','teamspeak.exe',
    'lunarclient.exe','badlion client.exe','tlauncher.exe','minecraftlauncher.exe','prismlauncher.exe',
    'modrinth app.exe','curseforge.exe','onedrive.exe','telegram.exe','whatsapp.exe')
$IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$Findings = New-Object System.Collections.ArrayList
function Add-Finding($cat, $item, $why) {
    [void]$Findings.Add([pscustomobject]@{ Category = $cat; Item = $item; Reason = $why })
}

# Only unambiguous cheat / injector names are matched (generic words removed)
$StrongKeywords = @('lilith','anubis','prestige','kronos','wexside','zeroday','killaura','autoclicker',
    'liquidbounce','wurst','aristois','bleachhack','mathax','impactclient','doomsday','meteorclient',
    'triggerbot','aimassist','vape','novoline','astolfo','raidercheat','hexclient','dreamclient',
    'rusherhack','salhack','phobos','futureclient','huzuni','weepcraft','ghostclient','slinky',
    'whiteout','konas','augustus','expensive','comcombat','com-combat')
function Test-Name([string]$text) {
    if (-not $text) { return $null }
    $t = $text.ToLowerInvariant()
    foreach ($k in $StrongKeywords) { if ($t.Contains($k)) { return $k } }
    return $null
}

function Rot13([string]$s) {
    $o = foreach ($c in $s.ToCharArray()) {
        if ($c -cmatch '[a-z]') { [char]((([int]$c - 97 + 13) % 26) + 97) }
        elseif ($c -cmatch '[A-Z]') { [char]((([int]$c - 65 + 13) % 26) + 65) }
        else { $c }
    }
    -join $o
}

function Test-Jar([string]$path) {
    try {
        $z = [System.IO.Compression.ZipFile]::OpenRead($path)
        foreach ($e in $z.Entries) {
            $en = $e.FullName.ToLowerInvariant()
            foreach ($s in $ContentSigs) {
                if ($en.Contains($s)) { $z.Dispose(); return "Jar entry '$($e.FullName)' matches '$s'" }
            }
        }
        # Fabric / Quilt / Forge metadata: only the mod id and name are checked
        foreach ($e in $z.Entries) {
            $en = $e.FullName.ToLowerInvariant()
            if ($en -in @('fabric.mod.json','quilt.mod.json','mcmod.info','meta-inf/mods.toml','meta-inf/neoforge.mods.toml')) {
                try {
                    $sr = New-Object IO.StreamReader($e.Open())
                    $meta = $sr.ReadToEnd(); $sr.Close()
                    $fields = @()
                    try {
                        $jm = $meta | ConvertFrom-Json
                        $fields = @("$($jm.id)", "$($jm.name)", "$($jm[0].modid)", "$($jm[0].name)")
                    } catch {
                        $fields = @(($meta -split "`n") | Where-Object { $_ -match 'modId|displayName' })
                    }
                    $mt = ($fields -join ' ').ToLowerInvariant()
                    foreach ($k in $StrongKeywords) {
                        if ($mt -match ("(^|[^a-z])" + [regex]::Escape($k) + "([^a-z]|$)")) { $z.Dispose(); return "Mod metadata '$($e.FullName)' matches '$k'" }
                    }
                } catch {}
            }
        }
        $z.Dispose()
    } catch {}
    return $null
}

# ---------------- progress bar ----------------
$stages = [ordered]@{
    'Processes' = 2; 'Java modules' = 5; 'Prefetch' = 3; 'Registry traces' = 5
    'Recycle Bin' = 3; 'Event logs' = 2; 'Mods and launcher' = 5; 'File scan' = 75
}
$script:base = 0; $script:w = 0; $script:cur = ''; $script:lastPct = -1; $script:lastLabel = ''
function Show-Bar([int]$pct, [string]$label) {
    if ($pct -gt 100) { $pct = 100 }
    if ($pct -eq $script:lastPct -and $label -eq $script:lastLabel) { return }
    $script:lastPct = $pct; $script:lastLabel = $label
    $shown = $label
    if ($lang -eq 'tr' -and $ST.ContainsKey($label)) { $shown = $ST[$label] }
    $n = [int]($pct / 2)
    $bar = "$OR" + ('#' * $n) + "$DK" + ('-' * (50 - $n)) + "$RS"
    $pc  = "$PU" + $pct.ToString().PadLeft(3) + "%$RS"
    $lb  = "$GD" + $shown.PadRight(24) + "$RS"
    Write-Host -NoNewline "`r[$bar] $pc  $lb"
}
function Start-Stage($name) { $script:cur = $name; $script:w = $stages[$name]; Show-Bar ([int]$script:base) $name }
function Step-Stage([double]$frac) { Show-Bar ([int]($script:base + $script:w * $frac)) $script:cur }
function Stop-Stage() { $script:base += $script:w; Show-Bar ([int]$script:base) $script:cur }

# ---------------- start ----------------
function Show-Banner {
    Write-Host "$PU============================================================$RS"
    Write-Host ("$OR                          " + (T 'banner') + $RS)
    Write-Host "                       dc : zulemayeniden"
    Write-Host "$PU============================================================$RS"
}

function Show-Header {
    Clear-Host
    if (-not $IsAdmin) {
        Write-Host ("$RD" + (T 'admin1') + $RS)
        Write-Host ("$RD" + (T 'admin2') + $RS)
    }
}
function Show-Boot {
    # Last user shutdown / restart (Event 1074) and last real start (Event 6005).
    # Win32 LastBootUpTime is not used here because Fast Startup makes a shutdown look like no reboot.
    $sd = Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 1074 } -MaxEvents 1 -ErrorAction SilentlyContinue
    $bt = Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 6005 } -MaxEvents 1 -ErrorAction SilentlyContinue
    if ($lang -eq 'tr') { $l1 = 'Son kapatma / yeniden başlatma'; $l2 = 'Son açılış'; $l3 = 'Açık kalma süresi'; $nf = 'bulunamadı' }
    else { $l1 = 'Last shutdown / restart'; $l2 = 'Last boot'; $l3 = 'Uptime'; $nf = 'not found' }
    if ($sd) { $s1 = $sd[0].TimeCreated.ToString('dd.MM.yyyy HH:mm') } else { $s1 = $nf }
    if ($bt) { $boot = $bt[0].TimeCreated } else {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        if ($os) { $boot = $os.LastBootUpTime } else { $boot = $null }
    }
    Write-Host ("$GD" + $l1 + ": " + $s1 + $RS)
    if ($boot) {
        $up = (Get-Date) - $boot
        Write-Host ("$GD" + $l2 + ": " + $boot.ToString('dd.MM.yyyy HH:mm') + $RS)
        Write-Host ("$GD" + $l3 + ": " + ("{0} d {1} h {2} min" -f $up.Days, $up.Hours, $up.Minutes) + $RS)
    }
}
function Get-Selection {
    Write-Host ''
    Write-Host ("$GD" + (T 'menu1') + $RS)
    Write-Host ("$GD" + (T 'menu2') + $RS)
    Write-Host ("$GD" + (T 'menu3') + $RS)
    Write-Host ("$GD" + (T 'menu4') + $RS)
    Write-Host ("$GD" + (T 'menu5') + $RS)
    Write-Host ("$DK" + (T 'hint') + $RS)
    $c = [string](Read-Host (T 'choose'))
    $scan = ''
    if ($c -match '2') { $scan = '2' } elseif ($c -match '1') { $scan = '1' }
    Write-Host ''
    return @{ Scan = $scan; Svc = [bool]($c -match '3'); Boot = [bool]($c -match '4'); Usb = [bool]($c -match '5') }
}
function Check-Services {
    if (-not $IsAdmin) { Write-Host ("$RD" + (T 'svcadmin') + $RS); return }
    $GN = "$([char]27)[38;2;110;200;120m"
    if ($lang -eq 'tr') {
        $hd = @('Servis Adı', 'Görünen Ad', 'Durum', 'PID', 'Başlangıç Zamanı'); $run = 'Çalışıyor'; $stp = 'Durdu'; $dis = 'Devre dışı'; $act = 'Aktif'; $off = 'Kapalı'
    } else {
        $hd = @('Service Name', 'Display Name', 'Status', 'PID', 'Start Time'); $run = 'Running'; $stp = 'Stopped'; $dis = 'Disabled'; $act = 'Active'; $off = 'Off'
    }
    $rows = New-Object System.Collections.ArrayList
    function Add-Row($n, $d, $st, $ok, $id, $t) {
        [void]$rows.Add([pscustomobject]@{ N = $n; D = $d; S = $st; Ok = $ok; P = $id; T = $t })
    }
    foreach ($svc in @(
        @{ N = 'SysMain';    D = 'SysMain (Superfetch)' },
        @{ N = 'PcaSvc';     D = 'Program Compatibility Assistant Service' },
        @{ N = 'DPS';        D = 'Diagnostic Policy Service' },
        @{ N = 'EventLog';   D = 'Windows Event Log' },
        @{ N = 'Schedule';   D = 'Task Scheduler' },
        @{ N = 'bam';        D = 'Background Activity Moderator' },
        @{ N = 'Dusmsvc';    D = 'Data Usage' },
        @{ N = 'Appinfo';    D = 'Application Information' },
        @{ N = 'CDPSvc';     D = 'Connected Devices Platform Service' },
        @{ N = 'DcomLaunch'; D = 'DCOM Server Process Launcher' },
        @{ N = 'PlugPlay';   D = 'Plug and Play' },
        @{ N = 'wsearch';    D = 'Windows Search' },
        @{ N = 'mpssvc';     D = 'Windows Defender Firewall' },
        @{ N = 'WinDefend';  D = 'Windows Defender Antivirus' })) {
        $s = Get-Service $svc.N -ErrorAction SilentlyContinue
        if (-not $s) { continue }
        $procId = ''; $tm = 'N/A'
        $ci = Get-CimInstance Win32_Service -Filter "Name='$($svc.N)'" -ErrorAction SilentlyContinue
        if ($ci -and $ci.ProcessId -gt 0) {
            $procId = [string]$ci.ProcessId
            $pr = Get-Process -Id $ci.ProcessId -ErrorAction SilentlyContinue
            if ($pr) { try { $tm = $pr.StartTime.ToString('dd.MM.yyyy HH:mm:ss') } catch {} }
        }
        $ok = ($s.Status -eq 'Running')
        if ($ok) { $st = $run } elseif ($s.StartType -eq 'Disabled') { $st = $dis } else { $st = $stp }
        Add-Row $svc.N $svc.D $st $ok $procId $tm
        if ($s.StartType -eq 'Disabled') { Add-Finding 'Bypass' $svc.D 'Service startup type is Disabled' }
        elseif (-not $ok -and $svc.N -ne 'WinDefend') { Add-Finding 'Bypass' $svc.D "Service is $($s.Status)" }
    }
    # Firewall profiles
    foreach ($f in @(Get-NetFirewallProfile -ErrorAction SilentlyContinue)) {
        if ($f.Enabled) { $st = $act } else { $st = $off }
        Add-Row "Firewall: $($f.Name)" 'Windows Firewall Profile' $st ([bool]$f.Enabled) '' ''
        if (-not $f.Enabled) { Add-Finding 'Bypass' "Firewall profile disabled: $($f.Name)" 'Windows Firewall profile is off' }
    }
    # Defender real-time protection / policy
    $dp = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -ErrorAction SilentlyContinue
    if ($dp -and $dp.DisableAntiSpyware -eq 1) { Add-Finding 'Bypass' 'Microsoft Defender Antivirus' 'Disabled by policy' }
    $mp = $null
    try { $mp = Get-MpComputerStatus -ErrorAction Stop } catch {}
    if ($mp) {
        if ($mp.RealTimeProtectionEnabled) { $st = $act } else { $st = $off }
        Add-Row 'Defender RTP' 'Real-time protection' $st ([bool]$mp.RealTimeProtectionEnabled) '' ''
        if (-not $mp.RealTimeProtectionEnabled) { Add-Finding 'Bypass' 'Defender real-time protection' 'Real-time protection is off' }
    }
    # USN Journal
    $usn = (& fsutil usn queryjournal $env:SystemDrive 2>&1 | Out-String)
    $usnOk = ($usn -match 'Usn Journal ID|USN Günlük Kimliği|ID')  -and ($usn -notmatch 'not active|etkin değil|Error|Hata')
    if ($usnOk) { $st = $act } else { $st = $off }
    Add-Row 'USN Journal' 'NTFS Change Journal' $st $usnOk '' $(if ($usnOk) { $act } else { '' })
    if (-not $usnOk) { Add-Finding 'Bypass' 'USN Journal' 'NTFS change journal is not active (possibly deleted)' }
    # Prefetch registry
    $ep = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -ErrorAction SilentlyContinue).EnablePrefetcher
    $epName = @{ 0 = 'Disabled'; 1 = 'Application'; 2 = 'Boot'; 3 = 'Full' }
    if ($null -ne $ep) { $epTxt = "$($epName[[int]$ep]) ($ep)" } else { $epTxt = 'N/A' }
    $epOk = ($ep -eq 3)
    if ($epOk) { $st = $run } else { $st = $dis }
    Add-Row 'Prefetch Registry' 'EnablePrefetcher' $st $epOk '' $epTxt
    if ($null -ne $ep -and -not $epOk) { Add-Finding 'Bypass' 'Prefetch Registry' "EnablePrefetcher is $epTxt" }

    $w = @(26, 44, 14, 8, 22)
    Write-Host ''
    $line = ''
    for ($i = 0; $i -lt 5; $i++) { $line += $hd[$i].PadRight($w[$i]) }
    Write-Host ("$PU" + $line + $RS)
    foreach ($r in $rows) {
        if ($r.Ok) { $c = $GN } else { $c = $RD }
        Write-Host ($r.N.PadRight($w[0]) + "$DK" + $r.D.PadRight($w[1]) + $RS + $c + $r.S.PadRight($w[2]) + $RS + "$DK" + ([string]$r.P).PadRight($w[3]) + ([string]$r.T) + $RS)
    }
}

function Show-UsbCore {
    $vendors = @{ '058F'='Alcor Micro Corp.'; '0951'='Kingston Technology'; '0781'='SanDisk Corp.'; '090C'='Silicon Motion, Inc.'
        '0930'='Toshiba Corp.'; '154B'='PNY Technologies'; '125F'='A-DATA Technology'; '1B1C'='Corsair'; '18A5'='Verbatim, Ltd.'
        '0BDA'='Realtek Semiconductor'; '1307'='USBest Technology'; '13FE'='Kingston Technology'; '8564'='Transcend Information'
        '058B'='Info-TEK Corp.'; '0EA0'='Ours Technology'; '1005'='Apacer Technology'; '0718'='Imation Corp.'; '04E8'='Samsung Electronics'
        '0BC2'='Seagate'; '1058'='Western Digital'; '059B'='Iomega'; '2537'='Orico'; '1F75'='Innostor Technology' }
    $devs = @{}
    $propGuid = '{83da6326-97a6-4088-9453-a1923f573b29}'
    function Get-RegTime([string]$keyPath, [string]$id) {
        try {
            $item = Get-Item -LiteralPath ($keyPath + '\Properties\' + $propGuid + '\' + $id) -ErrorAction Stop
            $b = $item.GetValue('')
            if ($b -is [byte[]] -and $b.Length -ge 8) { return [DateTime]::FromFileTime([BitConverter]::ToInt64($b, 0)) }
        } catch {}
        return $null
    }
    function Get-PnpTimes([string]$instId) {
        $res = @{ First = $null; Inst = $null; Last = $null; Rem = $null }
        try {
            $props = @(Get-PnpDeviceProperty -InstanceId $instId -KeyName 'DEVPKEY_Device_FirstInstallDate', 'DEVPKEY_Device_InstallDate', 'DEVPKEY_Device_LastArrivalDate', 'DEVPKEY_Device_LastRemovalDate' -ErrorAction Stop)
            foreach ($pp in $props) {
                if ($pp.Data -is [DateTime]) {
                    if ($pp.KeyName -eq 'DEVPKEY_Device_FirstInstallDate') { $res.First = $pp.Data }
                    elseif ($pp.KeyName -eq 'DEVPKEY_Device_InstallDate') { $res.Inst = $pp.Data }
                    elseif ($pp.KeyName -eq 'DEVPKEY_Device_LastArrivalDate') { $res.Last = $pp.Data }
                    elseif ($pp.KeyName -eq 'DEVPKEY_Device_LastRemovalDate') { $res.Rem = $pp.Data }
                }
            }
        } catch {}
        return $res
    }
    $fmt = 'dd.MM.yyyy HH:mm:ss'
    $cntTime = 0
    $cntReg = 0; $cntLog = 0; $cntWpd = 0; $cntEnum = 0

    # --- 1) registry: USBSTOR ---
    $rx = New-Object System.Text.RegularExpressions.Regex('^(Disk|CdRom)&Ven_(.*?)&Prod_(.*?)(&Rev_(.*))?$')
    foreach ($k in @(Get-ChildItem -Path 'HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR' -ErrorAction SilentlyContinue)) {
        $m = $rx.Match([string]$k.PSChildName)
        if (-not $m.Success) { continue }
        $ven = $m.Groups[2].Value; $prod = ($m.Groups[3].Value -replace '_', ' '); $rev = $m.Groups[5].Value
        foreach ($i in @(Get-ChildItem -LiteralPath $k.PSPath -ErrorAction SilentlyContinue)) {
            $serial = ([string]$i.PSChildName -replace '&\d+$', '')
            $fn = $null
            try { $fn = (Get-ItemProperty -LiteralPath $i.PSPath -ErrorAction Stop).FriendlyName } catch {}
            if (-not $fn) { $fn = ("$ven $prod").Trim() }
            $pt = Get-PnpTimes ('USBSTOR\' + [string]$k.PSChildName + '\' + [string]$i.PSChildName)
            $tF = $pt.First; if (-not $tF) { $tF = $pt.Inst }; if (-not $tF) { $tF = Get-RegTime $i.PSPath '0065' }; if (-not $tF) { $tF = Get-RegTime $i.PSPath '0064' }
            $tL = $pt.Last; if (-not $tL) { $tL = Get-RegTime $i.PSPath '0066' }
            $tR = $pt.Rem; if (-not $tR) { $tR = Get-RegTime $i.PSPath '0067' }
            if ($tF -or $tL -or $tR) { $cntTime++ }
            $devs[$serial.ToUpperInvariant()] = [pscustomobject]@{
                Serial = $serial; Name = $fn; Prod = $prod; Rev = $rev; Ven = $ven
                First = $tF; Last = $tL
                VID = ''; PID = ''; Cap = ''; FS = ''; Rem = $tR; Now = $false
            }
            $cntReg++
        }
    }

    # --- 2) VID / PID + the generic USB enum list (also catches UASP drives and phones) ---
    $enumRows = New-Object System.Collections.ArrayList
    foreach ($u in @(Get-ChildItem -Path 'HKLM:\SYSTEM\CurrentControlSet\Enum\USB' -ErrorAction SilentlyContinue)) {
        $um = [regex]::Match([string]$u.PSChildName, '^VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})$')
        if (-not $um.Success) { continue }
        $v = $um.Groups[1].Value.ToUpperInvariant(); $pd = $um.Groups[2].Value.ToUpperInvariant()
        foreach ($i in @(Get-ChildItem -LiteralPath $u.PSPath -ErrorAction SilentlyContinue)) {
            $ik = ([string]$i.PSChildName).ToUpperInvariant()
            if ($devs.ContainsKey($ik)) { $devs[$ik].VID = $v; $devs[$ik].PID = $pd }
            $svc = $null; $desc = $null
            try { $ip = Get-ItemProperty -LiteralPath $i.PSPath -ErrorAction Stop; $svc = [string]$ip.Service; $desc = [string]$ip.DeviceDesc; if ($ip.FriendlyName) { $desc = [string]$ip.FriendlyName } } catch {}
            if ($desc -and $desc.Contains(';')) { $desc = $desc.Substring($desc.LastIndexOf(';') + 1) }
            if ($svc -match '^(USBSTOR|UASPStor|WUDFWpdMtp|WpdUsb|usbccgp)$') {
                $pt2 = Get-PnpTimes ('USB\' + [string]$u.PSChildName + '\' + [string]$i.PSChildName)
                $et = $pt2.First; if (-not $et) { $et = $pt2.Inst }; if (-not $et) { $et = Get-RegTime $i.PSPath '0065' }; if (-not $et) { $et = Get-RegTime $i.PSPath '0064' }
                $el = $pt2.Last; if (-not $el) { $el = Get-RegTime $i.PSPath '0066' }
                $er0 = $pt2.Rem; if (-not $er0) { $er0 = Get-RegTime $i.PSPath '0067' }
                $ef = '-'; if ($et) { $ef = $et.ToString($fmt) }
                $elx = '-'; if ($el) { $elx = $el.ToString($fmt) }
                $erm = '-'; if ($er0) { $erm = $er0.ToString($fmt) }
                if ($el -and $er0 -and $er0 -lt $el) { if ($lang -eq 'tr') { $erm = 'Şu an takılı' } else { $erm = 'Connected now' } }
                $esort = [DateTime]::MinValue; if ($el) { $esort = $el } elseif ($et) { $esort = $et }
                [void]$enumRows.Add([pscustomobject]@{ Name = $desc; F = $ef; L = $elx; R = $erm; Inst = [string]$i.PSChildName; VID = $v; PID = $pd; Svc = $svc; SortKey = $esort })
                $cntEnum++
            }
        }
    }

    # --- 3) Windows Portable Devices (volume labels, phones / MTP) ---
    foreach ($wk in @(Get-ChildItem -Path 'HKLM:\SOFTWARE\Microsoft\Windows Portable Devices\Devices' -ErrorAction SilentlyContinue)) {
        $wn = [string]$wk.PSChildName
        $wfn = $null
        try { $wfn = (Get-ItemProperty -LiteralPath $wk.PSPath -ErrorAction Stop).FriendlyName } catch {}
        $wnu = $wn.ToUpperInvariant()
        $wmatched = $false
        foreach ($dk2 in @($devs.Keys)) {
            if ($wnu.Contains($dk2)) {
                $wmatched = $true
                if ($wfn -and -not $devs[$dk2].Name.Contains($wfn)) { $devs[$dk2].Name = ($devs[$dk2].Name + ' [' + $wfn + ']') }
            }
        }
        if (-not $wmatched) {
            $wm = [regex]::Match($wn, 'USB#VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})#([^#]+)#')
            if ($wm.Success) {
                $wser = ($wm.Groups[3].Value -replace '&\d+$', '')
                $wkey = $wser.ToUpperInvariant()
                if (-not $devs.ContainsKey($wkey)) {
                    $wname = $wfn; if (-not $wname) { $wname = 'Portable Device' }
                    $devs[$wkey] = [pscustomobject]@{
                        Serial = $wser; Name = $wname; Prod = 'Portable Device'; Rev = ''; Ven = ''
                        First = $null; Last = $null
                        VID = $wm.Groups[1].Value.ToUpperInvariant(); PID = $wm.Groups[2].Value.ToUpperInvariant(); Cap = ''; FS = ''; Rem = $null; Now = $false
                    }
                    $cntWpd++
                }
            }
        }
    }

    # --- 4) capacity / file system (only while connected) ---
    foreach ($dd in @(Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceType -eq 'USB' })) {
        foreach ($dk2 in @($devs.Keys)) {
            if ($dd.PNPDeviceID -and $dd.PNPDeviceID.ToUpperInvariant().Contains($dk2)) {
                $devs[$dk2].Cap = ('{0:N1} GB' -f ($dd.Size / 1e9))
                $devs[$dk2].Now = $true
                try {
                    $fsl = @(Get-CimAssociatedInstance -InputObject $dd -Association Win32_DiskDriveToDiskPartition |
                        ForEach-Object { Get-CimAssociatedInstance -InputObject $_ -Association Win32_LogicalDiskToPartition } |
                        ForEach-Object { $_.FileSystem })
                    if ($fsl.Count -gt 0) { $devs[$dk2].FS = [string]$fsl[0] }
                } catch {}
            }
        }
    }

    # --- 5) setupapi logs: connection times, and devices whose registry key was deleted ---
    $sess = @{}
    $meta = @{}
    $rxDev = New-Object System.Text.RegularExpressions.Regex('^>>>\s+\[Device Install.*USBSTOR\\([^\\]+)\\([^\]\\]+)\]')
    $rxSec = New-Object System.Text.RegularExpressions.Regex('^>>>\s+Section start (\d{4})/(\d\d)/(\d\d) (\d\d):(\d\d):(\d\d)')
    foreach ($lg in @(Get-ChildItem -Path (Join-Path $env:windir 'INF') -Filter 'setupapi.dev*.log' -ErrorAction SilentlyContinue)) {
        $cur = $null
        $sr = $null
        try {
            $sr = New-Object IO.StreamReader((New-Object IO.FileStream($lg.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)))
            while ($null -ne ($ln = $sr.ReadLine())) {
                $m1 = $rxDev.Match($ln)
                if ($m1.Success) {
                    $cur = ($m1.Groups[2].Value -replace '&\d+$', '').ToUpperInvariant()
                    if (-not $meta.ContainsKey($cur)) { $meta[$cur] = $m1.Groups[1].Value }
                    continue
                }
                if ($cur) {
                    $m2 = $rxSec.Match($ln)
                    if ($m2.Success) {
                        $t = New-Object DateTime ([int]$m2.Groups[1].Value), ([int]$m2.Groups[2].Value), ([int]$m2.Groups[3].Value), ([int]$m2.Groups[4].Value), ([int]$m2.Groups[5].Value), ([int]$m2.Groups[6].Value)
                        if (-not $sess.ContainsKey($cur)) { $sess[$cur] = New-Object System.Collections.ArrayList }
                        [void]$sess[$cur].Add($t); $cur = $null
                    }
                }
            }
        } catch {}
        if ($sr) { try { $sr.Close() } catch {} }
    }
    foreach ($mk in @($meta.Keys)) {
        if ($devs.ContainsKey($mk)) { continue }
        $mm = [regex]::Match([string]$meta[$mk], '^(?:Disk|CdRom)&Ven_(.*?)&Prod_(.*?)(?:&Rev_(.*))?$')
        $lv = ''; $lp = [string]$meta[$mk]; $lr = ''
        if ($mm.Success) { $lv = $mm.Groups[1].Value; $lp = ($mm.Groups[2].Value -replace '_', ' '); $lr = $mm.Groups[3].Value }
        $devs[$mk] = [pscustomobject]@{
            Serial = $mk; Name = (("$lv $lp").Trim() + ' (registry silinmis / deleted)'); Prod = $lp; Rev = $lr; Ven = $lv
            First = $null; Last = $null; VID = ''; PID = ''; Cap = ''; FS = ''; Rem = $null; Now = $false
        }
        $cntLog++
    }

    Write-Host ''
    Write-Host ("$DK" + ('[i] USBSTOR: {0} | setupapi (registry silinmis): {1} | WPD: {2} | USB enum: {3} | zaman okunan: {4}' -f $cntReg, $cntLog, $cntWpd, $cntEnum, $cntTime) + $RS)

    if ($devs.Count -eq 0 -and $enumRows.Count -eq 0) {
        if (-not $IsAdmin) {
            if ($lang -eq 'tr') { Write-Host ("$RD" + '[!] Yönetici olarak çalıştırılmadığı için USB kayıtları okunamamış olabilir. Run.bat ile açın.' + $RS) }
            else { Write-Host ("$RD" + '[!] Not running as administrator, USB registry keys may be unreadable. Use Run.bat.' + $RS) }
        }
        Write-Host ("$GD" + (T 'usbnone') + $RS)
        return
    }

    # --- build rows (one row per device) ---
    $rows = New-Object System.Collections.ArrayList
    $tNow = if ($lang -eq 'tr') { 'Şu an takılı' } else { 'Connected now' }
    foreach ($key in @($devs.Keys)) {
        $d = $devs[$key]
        $first = $d.First; $last = $d.Last
        if ($sess.ContainsKey($key)) {
            $st = @($sess[$key] | Sort-Object)
            if ($st.Count -gt 0) {
                if (-not $first -or $st[0] -lt $first) { $first = $st[0] }
                if (-not $last) { $last = $st[$st.Count - 1] }
            }
        }
        $now = [bool]$d.Now
        if (-not $now -and $d.Last -and $d.Rem -and $d.Rem -lt $d.Last) { $now = $true }
        $f = '-'; if ($first) { $f = $first.ToString($fmt) }
        $l = '-'; if ($last) { $l = $last.ToString($fmt) }
        $rm = '-'; if ($now) { $rm = $tNow } elseif ($d.Rem) { $rm = $d.Rem.ToString($fmt) }
        $so = [DateTime]::MinValue; if ($last) { $so = $last } elseif ($first) { $so = $first }
        [void]$rows.Add([pscustomobject]@{ D = $d; F = $f; L = $l; R = $rm; SortKey = $so })
    }
    if ($lang -eq 'tr') { $hd = @('Aygıt Adı','İlk Bağlantı','Son Takılma','Son Çıkarılma','Kapasite','Seri Numarası','Ürün Adı','Üretici Adı','VID','PID','Revizyon','Dosya Sistemi') }
    else { $hd = @('Device Name','First Connected','Last Plugged In','Last Removed','Capacity','Serial Number','Product Name','Manufacturer','VID','PID','Revision','File System') }
    $w = @(22, 20, 20, 20, 9, 17, 14, 20, 5, 5, 9, 11)
    $cw = 120; try { $cw = $Host.UI.RawUI.WindowSize.Width } catch {}
    if (-not $cw -or $cw -lt 40) { $cw = 120 }
    $cols = New-Object System.Collections.ArrayList
    foreach ($ci in 0..11) { [void]$cols.Add($ci) }
    foreach ($drop in @(10, 11, 6, 7, 4, 8, 9)) {
        $tot = 0; foreach ($ci in $cols) { $tot += $w[$ci] }
        if ($tot -lt $cw) { break }
        $cols.Remove($drop)
    }
    if ($rows.Count -gt 0) {
        Write-Host ''
        $line = ''
        foreach ($ci in $cols) { $line += ([string]$hd[$ci]).PadRight($w[$ci]) }
        Write-Host ("$PU" + $line + $RS)
        foreach ($r in @($rows | Sort-Object -Property SortKey -Descending)) {
            $d = $r.D
            $vn = $d.Ven; if ($d.VID -and $vendors.ContainsKey($d.VID)) { $vn = $vendors[$d.VID] }
            $cp = 'N/A'; if ($d.Cap) { $cp = $d.Cap }
            $vi = '-'; if ($d.VID) { $vi = $d.VID }
            $pi2 = '-'; if ($d.PID) { $pi2 = $d.PID }
            $fs2 = 'N/A'; if ($d.FS) { $fs2 = $d.FS }
            $vals = @($d.Name, $r.F, $r.L, $r.R, $cp, $d.Serial, $d.Prod, $vn, $vi, $pi2, $d.Rev, $fs2)
            $line = ''
            foreach ($ci in $cols) {
                $cell = [string]$vals[$ci]; if ($cell.Length -ge $w[$ci]) { $cell = $cell.Substring(0, $w[$ci] - 1) }
                $line += $cell.PadRight($w[$ci])
            }
            Write-Host ("$DK" + $line + $RS)
        }
    }

    # --- generic USB enum table (every storage / phone USB device Windows ever enumerated) ---
    if ($enumRows.Count -gt 0) {
        $ew = @(30, 20, 20, 20, 20, 6, 6, 12)
        if ($lang -eq 'tr') { $eh = @('Aygıt (USB enum)', 'İlk Bağlantı', 'Son Takılma', 'Son Çıkarılma', 'Örnek Kimliği', 'VID', 'PID', 'Servis') }
        else { $eh = @('Device (USB enum)', 'First Connected', 'Last Plugged In', 'Last Removed', 'Instance ID', 'VID', 'PID', 'Service') }
        Write-Host ''
        $line = ''
        for ($ci = 0; $ci -lt 8; $ci++) { $line += ([string]$eh[$ci]).PadRight($ew[$ci]) }
        Write-Host ("$PU" + $line + $RS)
        foreach ($er in @($enumRows | Sort-Object -Property SortKey -Descending)) {
            $ev = @($er.Name, $er.F, $er.L, $er.R, $er.Inst, $er.VID, $er.PID, $er.Svc)
            $line = ''
            for ($ci = 0; $ci -lt 8; $ci++) {
                $cell = [string]$ev[$ci]; if ($cell.Length -ge $ew[$ci]) { $cell = $cell.Substring(0, $ew[$ci] - 1) }
                $line += $cell.PadRight($ew[$ci])
            }
            Write-Host ("$DK" + $line + $RS)
        }
    }
}
function Show-Usb {
    try { Show-UsbCore } catch { Write-Host ("$RD" + '[!] USB error: ' + $_.Exception.Message + $RS) }
    Write-Host ''
}

function Show-Results {
# ---------------- results ----------------
Write-Host ''
$uniq = @($Findings | Sort-Object Category, Item -Unique)
foreach ($g in (@($uniq | Group-Object Category) | Sort-Object { $_.Name -eq 'Program' })) {
    $cn = $g.Name
    if ($lang -eq 'tr' -and $CT.ContainsKey($cn)) { $cn = $CT[$cn] }
    Write-Host ''
    Write-Host ("$PU" + $cn.ToUpper() + "  (" + $g.Count + ")" + $RS)
    foreach ($x in $g.Group) {
        $item = [string]$x.Item
        if ($item -match '[\\/]') { $name = Split-Path $item -Leaf; $path = $item } else { $name = $item; $path = '' }
        $cw = 120; try { $cw = $Host.UI.RawUI.WindowSize.Width } catch {}
        if ($name.Length -gt 40) { $name = $name.Substring(0, 37) + '...' }
        $room = $cw - 48
        if ($room -lt 10) { $room = 10 }
        if ($path.Length -gt $room) { $path = '...' + $path.Substring($path.Length - ($room - 3)) }
        Write-Host ("  " + $name.PadRight(44) + "$DK" + $path + $RS)
    }
}
}

function Invoke-Scan([string]$choice, [bool]$checkSvc) {
$Findings.Clear()
$script:base = 0; $script:lastPct = -1; $script:lastLabel = ''
$start = Get-Date
# 1) Processes
Start-Stage 'Processes'
$procs = @(Get-CimInstance Win32_Process)
$i = 0
foreach ($p in $procs) {
    $i++; if ($i % 20 -eq 0) { Step-Stage ($i / $procs.Count) }
    if ($CommonApps -contains $p.Name.ToLowerInvariant()) {
        Add-Finding 'Program' ($(if ($p.ExecutablePath) { $p.ExecutablePath } else { $p.Name })) 'common'
    }
    $k = Test-Name $p.Name
    if ($k) { Add-Finding 'Process' "$($p.Name) (PID $($p.ProcessId))" "Name match '$k' | $($p.ExecutablePath)" }
    if ($p.Name -match '^javaw?\.exe$' -and $p.CommandLine) {
        $ck = Test-Name $p.CommandLine
        if ($ck) { Add-Finding 'Process' "$($p.Name) (PID $($p.ProcessId))" "Command line match '$ck'" }
    }
    if ($p.Name -match '^javaw?\.exe$' -and $p.CommandLine -match '-(javaagent|agentpath|agentlib|Xbootclasspath)') {
        Add-Finding 'Java Agent' "$($p.Name) (PID $($p.ProcessId))" "Suspicious JVM argument: $($Matches[0])"
    }
}
Stop-Stage

# 2) Modules loaded in Java (injected DLLs)
Start-Stage 'Java modules'
$jp = @(Get-Process javaw, java)
$j = 0
foreach ($p in $jp) {
    $j++; Step-Stage ($j / [math]::Max($jp.Count, 1))
    foreach ($m in $p.Modules) {
        $path = $m.FileName
        $k = Test-Name (Split-Path $path -Leaf)
        if ($k) { Add-Finding 'Java Module' $path "Name match '$k' (PID $($p.Id))"; continue }
        if ($path -notmatch '\\Windows\\|\\Program Files|\\\.minecraft\\runtime|\\jre|\\jdk|\\java|lwjgl|jna|glfw|openal|jemalloc|\\natives|\\bin\\|\\runtime\\') {
            $sig = Get-AuthenticodeSignature $path
            if ($sig.Status -ne 'Valid' -and $path -match '\\(Temp|Downloads|Desktop|Documents|AppData)\\') { Add-Finding 'Java Module' $path "Unsigned module inside Java (possible injected DLL, review manually)" }
        }
    }
}
Stop-Stage

# 3) Prefetch + prefetch bypass
Start-Stage 'Prefetch'
$pf = @(Get-ChildItem 'C:\Windows\Prefetch' -Filter *.pf -Force)
if ($IsAdmin -and $pf.Count -eq 0) { Add-Finding 'Bypass' 'Prefetch' 'Prefetch folder is empty (cleared or disabled)' }
$ep = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters').EnablePrefetcher
if ($ep -eq 0) { Add-Finding 'Bypass' 'Prefetch' 'Prefetcher is disabled in registry' }
$sm = Get-Service SysMain
if ($sm -and $sm.Status -ne 'Running') { Add-Finding 'Bypass' 'SysMain service' "SysMain is $($sm.Status) (Prefetch needs it)" }
$i = 0
foreach ($f in $pf) {
    $i++; if ($i % 20 -eq 0) { Step-Stage ($i / $pf.Count) }
    $k = Test-Name $f.Name
    if ($k) { Add-Finding 'Prefetch' $f.Name "Name match '$k' | last run $($f.LastWriteTime)" }
}
Stop-Stage

# 4) Registry execution traces (show files even if deleted)
Start-Stage 'Registry traces'
function Scan-RegKey($path, $label, [bool]$checkExists) {
    $props = (Get-ItemProperty -Path $path).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }
    foreach ($pr in $props) {
        if ($pr.Name -match '\.ApplicationCompany$') { continue }
        $clean = $pr.Name -replace '\.FriendlyAppName$', ''
        $k = Test-Name (Split-Path $clean -Leaf)
        if ($k) {
            $why = "Name match '$k'"
            if ($checkExists -and -not (Test-Path -LiteralPath $clean)) { $why += ' | FILE NO LONGER EXISTS (deleted/moved)' }
            Add-Finding $label $clean $why
        }
    }
}
foreach ($bam in @('HKLM:\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings', 'HKLM:\SYSTEM\CurrentControlSet\Services\bam\UserSettings')) {
    Get-ChildItem $bam | ForEach-Object { Scan-RegKey $_.PSPath 'BAM' $false }
}
Step-Stage 0.4
Scan-RegKey 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache' 'MuiCache' $true
Scan-RegKey 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Compatibility Assistant\Store' 'AppCompat' $true
Step-Stage 0.7
Get-ChildItem 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist' | ForEach-Object {
    $props = (Get-ItemProperty -Path "$($_.PSPath)\Count").PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }
    foreach ($pr in $props) {
        $dec = Rot13 $pr.Name
        $k = Test-Name (Split-Path $dec -Leaf)
        if ($k) { Add-Finding 'UserAssist' $dec "Name match '$k'" }
    }
}
Stop-Stage

# 5) Recycle Bin (deleted files)
Start-Stage 'Recycle Bin'
$ifiles = @(Get-ChildItem 'C:\$Recycle.Bin' -Force -Recurse -File | Where-Object { $_.Name -like '$I*' })
$i = 0
foreach ($f in $ifiles) {
    $i++; if ($i % 10 -eq 0) { Step-Stage ($i / $ifiles.Count) }
    try {
        $b = [IO.File]::ReadAllBytes($f.FullName)
        $off = 24; if ($b[0] -eq 2) { $off = 28 }
        $orig = [Text.Encoding]::Unicode.GetString($b, $off, $b.Length - $off).TrimEnd([char]0)
        $k = Test-Name (Split-Path $orig -Leaf)
        if ($k) { Add-Finding 'Deleted file' $orig "Name match '$k' | deleted $($f.LastWriteTime)" }
    } catch {}
}
Stop-Stage

# 6) Event logs / USN journal (trace-cleaning)
Start-Stage 'Event logs'
if ($IsAdmin) {
    foreach ($q in @(@{ LogName = 'Security'; Id = 1102 }, @{ LogName = 'System'; Id = 104 })) {
        foreach ($e in @(Get-WinEvent -FilterHashtable $q -MaxEvents 3)) {
            Add-Finding 'Bypass' "$($q.LogName) event log cleared" "Cleared at $($e.TimeCreated)"
        }
    }
    Step-Stage 0.6
    $usn = & fsutil usn queryjournal C: 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0 -or $usn -match 'not active') {
        Add-Finding 'Bypass' 'USN Journal (C:)' 'Journal not active or deleted (traces may have been wiped)'
    }
}
Stop-Stage

# 7) Mods folder + launcher
Start-Stage 'Mods and launcher'
$mc = Join-Path $env:APPDATA '.minecraft'
$jars = @(Get-ChildItem (Join-Path $mc 'mods') -Filter *.jar -Recurse -Force)
$i = 0
foreach ($f in $jars) {
    $i++; Step-Stage (0.7 * $i / [math]::Max($jars.Count, 1))
    $k = Test-Name $f.Name
    if ($k) { Add-Finding 'Mod' $f.FullName "Name match '$k'" }
    $r = Test-Jar $f.FullName
    if ($r) { Add-Finding 'Mod' $f.FullName $r }
}
Get-ChildItem (Join-Path $mc 'versions') -Directory | ForEach-Object {
    $k = Test-Name $_.Name
    if ($k) { Add-Finding 'Version' $_.FullName "Version folder name match '$k'" }
}
$lp = Join-Path $mc 'launcher_profiles.json'
if (Test-Path $lp) {
    $txt = Get-Content $lp -Raw
    if ($txt -match '-javaagent[^"]*') { Add-Finding 'Launcher' $lp "javaagent in profile: $($Matches[0])" }
}
Stop-Stage

# 8) File scan
Start-Stage 'File scan'
$home_ = $env:USERPROFILE
if ($choice -eq '2') {
    $roots = @([IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq 'Fixed' } | ForEach-Object { $_.Name })
} else {
    $roots = @(
        "$home_\Desktop", "$home_\Downloads", "$home_\Documents", "$home_\OneDrive\Desktop",
        "$env:APPDATA", "$env:APPDATA\Microsoft\Windows\Recent",
        "$env:LOCALAPPDATA\Temp", "$env:SystemRoot\Temp"
    ) | Where-Object { Test-Path $_ }
}
$extSet = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($e in $ScanExt) { [void]$extSet.Add($e) }
$files = New-Object System.Collections.Generic.List[string]
$stack = New-Object System.Collections.Generic.Stack[string]
foreach ($r in $roots) { $stack.Push($r) }
Show-Bar ([int]$script:base) 'Listing files...'
while ($stack.Count -gt 0) {
    $d = $stack.Pop()
    $dk = Test-Name (Split-Path $d -Leaf)
    if ($dk) { Add-Finding 'Folder' $d "Folder name match '$dk'" }
    if ($d -match '\\Windows\\(WinSxS|System32|SysWOW64|assembly)|\$Recycle\.Bin|\\node_modules') { continue }
    try { foreach ($x in [IO.Directory]::EnumerateFiles($d)) { if ($extSet.Contains([IO.Path]::GetExtension($x).ToLowerInvariant())) { $files.Add($x) } } } catch {}
    try { foreach ($s in [IO.Directory]::EnumerateDirectories($d)) { $stack.Push($s) } } catch {}
}
$total = $files.Count
$i = 0
$latin = [Text.Encoding]::GetEncoding(28591)
foreach ($f in $files) {
    $i++; if ($i % 25 -eq 0) { Step-Stage ($i / [math]::Max($total, 1)) }
    $name = [IO.Path]::GetFileName($f)
    $ext = [IO.Path]::GetExtension($f).ToLowerInvariant()
    $k = Test-Name $name
    if ($k) { Add-Finding 'File' $f "Filename match '$k'" }
    if ($f -match '\\(Downloads|Desktop|Documents)\\') {
        $zi = Get-Content -LiteralPath $f -Stream Zone.Identifier -ErrorAction SilentlyContinue | Out-String
        if ($zi -match 'discord') { Add-Finding 'Discord download' $f 'Downloaded from Discord' }
    }
    if ($name -match '\.(png|jpg|jpeg|gif|txt|pdf|docx?|mp3|mp4)\.(exe|jar|dll|bat|scr)$') {
        Add-Finding 'Disguised' $f 'Double extension (executable disguised as another file type)'
    }
    $size = 0
    try { $size = (New-Object IO.FileInfo $f).Length } catch {}
    if ($DisguiseExt -contains $ext -and $size -ge 4) {
        try {
            $fs = [IO.File]::Open($f, 'Open', 'Read', 'ReadWrite')
            $buf = New-Object byte[] 4; [void]$fs.Read($buf, 0, 4); $fs.Close()
            if ($buf[0] -eq 0x4D -and $buf[1] -eq 0x5A) {
                Add-Finding 'Disguised' $f "Executable (MZ header) renamed to $ext"
            } elseif ($buf[0] -eq 0x50 -and $buf[1] -eq 0x4B -and $buf[2] -eq 3 -and $buf[3] -eq 4) {
                $why = "ZIP/JAR archive renamed to $ext"
                if ($size -le $MaxContentSize) { $r = Test-Jar $f; if ($r) { $why += " | $r" } }
                Add-Finding 'Disguised' $f $why
            }
        } catch {}
    }
    if ($ContentExt -contains $ext -and $size -gt 0 -and ($ext -eq '.jar' -or $size -le $MaxContentSize)) {
        if ($ext -eq '.jar') {
            $r = Test-Jar $f
            if ($r) { Add-Finding 'File content' $f $r }
        } else {
            try {
                $txt = $latin.GetString([IO.File]::ReadAllBytes($f)).ToLowerInvariant()
                foreach ($s in $ContentSigs) {
                    if ($txt.Contains($s)) { Add-Finding 'File content' $f "Binary contains signature '$s'"; break }
                }
            } catch {}
        }
    }
}
Stop-Stage
Show-Bar 100 'Done'
Write-Host ''

if ($checkSvc) { Check-Services }
Show-Results
}

Show-Header
while ($true) {
    Show-Banner
    $sel = Get-Selection
    if (-not ($sel.Scan -or $sel.Svc -or $sel.Boot -or $sel.Usb)) { continue }
    if ($sel.Boot) { Show-Boot }
    if ($sel.Usb) { Show-Usb }
    if ($sel.Scan) {
        Invoke-Scan $sel.Scan $sel.Svc
    } elseif ($sel.Svc) {
        $Findings.Clear()
        Check-Services
        Show-Results
    }
    if ($sel.Scan -or $sel.Svc) {
        if ($lang -eq 'tr') { $done = 'Tarama tamamlandı.' } else { $done = 'Scan complete.' }
        Write-Host ''
        Write-Host ("$GD" + $done + $RS)
    }
}
